# Ezpayit


yarn add react-native-linear-gradient
yarn add react-native-navigation 
expo install expo-linear-gradient   
yarn add react-native-animatable 
expo install react-native-gesture-handler react-native-reanimated react-native-screens react-native-safe-area-context @react-native-community/masked-view
yarn add react-native-paper
expo install @react-native-async-storage/async-storage
yarn start 
